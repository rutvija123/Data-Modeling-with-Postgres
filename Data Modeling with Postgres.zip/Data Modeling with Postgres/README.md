Data Modeling with Postgres 


Introduction:
This project is for developing a music streaming app which is known as Sparkify. Here Important thing is to do the analysis of users choice for the songs.Data of songes are already provided in json song_data files and user's choices are shown in log_data folder having json format.Sparkify database is created and queries are written to fetch required data.

Purpose:
The purpose of this project is to create a database and manage queries to help analytics team to analyse user's choices for songs.

Database: Sparkify

Created Tables: 

